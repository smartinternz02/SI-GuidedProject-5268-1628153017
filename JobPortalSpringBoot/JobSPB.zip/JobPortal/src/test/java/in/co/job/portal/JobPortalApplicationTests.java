package in.co.job.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
