package in.co.job.portal.exception;


public class DatabaseException  extends Exception
{

   public DatabaseException(String msg) {
       super(msg);
   }
}

